<?php
        $hosturl = $_SERVER['HTTP_HOST'];
        $updatehost = 'http://sq.123cf.top/update.php';
        $updatehosturl = $updatehost . '?a=client_check_time&v=' . $ver . '&u=' . $hosturl;
        $domain_time = file_get_contents($updatehosturl);
        if($domain_time == '0'){
            $domain_time = '[授权版本：授权已过期，请联系客服QQ:1578411229]';
        }else{
            $domain_time = '授权版本：(众航源码商业版)--到期时间：(' . date("Y-m-d", $domain_time) . ')';
        }

unset($domain);

?>