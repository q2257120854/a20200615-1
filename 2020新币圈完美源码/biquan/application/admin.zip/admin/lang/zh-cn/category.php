<?php

return [
    'Id'          => 'ID',
    'Pid'         => '父ID',
    'Type'        => '栏目类型',
    'All'         => '全部',
    'Image'       => '图片',
    'Keywords'    => '关键字',
    'Description' => '描述',
    'Diyname'     => '自定义名称',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间',
    'Weigh'       => '权重',
    'Status'      => '状态'
];
